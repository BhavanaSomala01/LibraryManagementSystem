This project aim to create a library management software LMS.
Our group task is to maintain inventory and report generation.
